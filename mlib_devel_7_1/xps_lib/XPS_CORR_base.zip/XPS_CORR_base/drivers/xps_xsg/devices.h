/* ********************************* */
/* *                               * */
/* *    BEE2 Start-up test suite   * */
/* *                               * */
/* ********************************* */

/* 2004 Pierre-Yves droz */

/* Devices access functions */

#ifndef DEVICES_H
#define DEVICES_H 

/* includes */
/* ********************************* */
#include "../core_info.h"

/* Prototypes */
/* ********************************* */
void listdev_cmd(int argc, char **argv);

/* Constants */
/* ********************************* */

#endif
