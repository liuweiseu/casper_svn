/* ********************************* */
/* *                               * */
/* *    BEE2 Start-up test suite   * */
/* *                               * */
/* ********************************* */

/* 2004 Pierre-Yves droz */

/* Main file */

#include "xparameters.h"
#include "xuartlite_l.h"
#include "xcache_l.h"
#include "tinysh.h"
#include <stdio.h>
#include <stdlib.h>

/* Prototypes */
/* ********************************* */
void add_cmds();
void outbyte(unsigned char c);
int  inbyte();
/* <prototypes> */

/* Commands */
/* ********************************* */
/* <commands_defs> */

/* Main thread */
/* ********************************* */

int main(void)
{
	int i;

/* activate the cache on the PPC */
    XCache_EnableICache(0x00000001);
    XCache_EnableDCache(0x00000001);

/* display welcome message */
	xil_printf("\n\r");
	xil_printf("****************************\n\r");
	xil_printf("* TinySH lightweight shell *\n\r");
	xil_printf("****************************\n\r");
/* <hello> */
	xil_printf("\n\r");
	xil_printf("DON'T PANIC ;-)\n\r");
	xil_printf("\n\r");
	xil_printf("Type 'help' for help\n\r");
	xil_printf("Type '?' for a list of available commands\n\r");
	xil_printf("\n\r");

/* add all the commands */
/* <commands_adds> */

/* add user initilization calls */
/* <inits> */

/* change the prompt */
	tinysh_set_prompt("CORR % ");

/* loop waiting for chars */
	while(1) {
		tinysh_char_in(inbyte());
	}

}


/* Tinysh support */
/* ********************************* */

/* we must provide these functions to use tinysh
 */
void tinysh_char_out(unsigned char c)
{
	outbyte(c);
}

void outbyte(unsigned char c)
{
	XUartLite_SendByte(STDOUT_BASEADDRESS, c);
}

int inbyte()
{
	while (XUartLite_mIsReceiveEmpty(XPAR_RS232_UART_1_BASEADDR))
	{
/* <repeats> */
	}

	return (Xuint8)XIo_In32(XPAR_RS232_UART_1_BASEADDR + XUL_RX_FIFO_OFFSET);
}
