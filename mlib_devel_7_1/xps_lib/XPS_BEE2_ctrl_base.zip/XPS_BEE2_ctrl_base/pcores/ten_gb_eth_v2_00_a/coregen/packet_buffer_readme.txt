The following files were generated for 'packet_buffer' in directory 
/home/droz/10GbE/ten_Gb_eth/:

packet_buffer_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

packet_buffer.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

packet_buffer.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

packet_buffer.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

packet_buffer_readme.txt:
   Text file indicating the files generated and how they are used.

packet_buffer.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

