The following files were generated for 'address_fifo' in directory 
/home/droz/CVS/repository/pcores/ten_gb_eth_v2_00_a/coregen/:

address_fifo.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

address_fifo_readme.txt:
   Text file indicating the files generated and how they are used.

address_fifo.vhd:
   Unisim VHDL file containing the information required to simulate
   the module.

address_fifo.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

address_fifo_fifo_generator_v3_1_xst_1.ngc:
   Binary Xilinx implementation netlist. The logic implementation of
   certain CORE Generator IP is described by a combination of a top
   level EDN file plus one or more NGC files.

address_fifo.edn:
   Electronic Data Netlist (EDN) file containing the information
   required to implement the module in a Xilinx (R) FPGA.

address_fifo_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

